var CloudConstruct;
(function (CloudConstruct) {
    var Point = (function () {
        function Point(x, y) {
            this.x = x;
            this.y = y;
        }
        return Point;
    }());
    var Cloud = (function () {
        function Cloud(selector, point) {
            this.selector = selector;
            this.point = point;
        }
        Cloud.isSeparately = function (allClouds, currentPoint, offset, width, height) {
            if (offset === void 0) { offset = 0; }
            if (allClouds.length === 0)
                return true;
            allClouds.forEach(function (element) {
                if (Cloud.intoRange(element.point.x - offset - Cloud.width / 2, element.point.x + offset + Cloud.width / 2, currentPoint.x))
                    return false;
                if (Cloud.intoRange(element.point.y - offset - Cloud.height / 2, element.point.y + offset + Cloud.height / 2, currentPoint.y))
                    return false;
            });
            if (currentPoint.x > width - Cloud.width - offset || currentPoint.x < Cloud.width + offset || currentPoint.y > height - Cloud.height - offset || currentPoint.y < Cloud.height + offset)
                return false;
            return true;
        };
        Cloud.intoRange = function (start, end, x) {
            return x < start || x > end ? false : true;
        };
        Cloud.getAllClouds = function (cssSelector) {
            var clouds = $(cssSelector);
            if (clouds.length === 0)
                return [];
            return clouds;
        };
        return Cloud;
    }());
    var Field = (function () {
        function Field(fieldSelector, cloudWidth, cloudHeight, LevelMax) {
            this.firstClick = true;
            this.cloudCount = 0;
            this.cloudsJQuery = Cloud.getAllClouds(".cloudMan .cloud");
            this.fieldSelector = fieldSelector;
            this.width = $(fieldSelector).width();
            this.height = $(fieldSelector).height();
            this.LevelMax = LevelMax;
            Cloud.width = cloudWidth;
            Cloud.height = cloudHeight;
            this.LevelStep = LevelMax / this.getCloudCount();
            this.Level = this.LevelStep;
        }
        Field.prototype.init = function () {
            this.clouds = [];
            var selector;
            this.cloudCount = this.cloudsJQuery.length;
            for (var i = 0; i < this.cloudsJQuery.length; i++) {
                selector = "." + this.cloudsJQuery[i].className.replace(' ', '.');
                this.clouds.push(new Cloud(selector, this.getRandomPoint()));
                $(selector).css("left", this.clouds[i].point.x + "px");
                $(selector).css("top", this.clouds[i].point.y + "px");
            }
        };
        Field.prototype.getRandomPoint = function () {
            var cloudNotIsSeparately = true;
            var point;
            var k = 0;
            while (cloudNotIsSeparately) {
                var x = this.random(0, this.width - Cloud.width);
                var y = this.random(0, this.height - Cloud.height);
                point = new Point(x, y);
                cloudNotIsSeparately = !Cloud.isSeparately(this.clouds, point, 10, this.width, this.height);
                if (k++ > 500)
                    throw ("Нету места для нового облака!!!");
            }
            return point;
        };
        Field.prototype.random = function (min, max) {
            var rand = min - 0.5 + Math.random() * (max - min + 1);
            rand = Math.round(rand);
            return rand;
        };
        Field.prototype.actionOnClick = function (element) {
            this.Level = Math.round(this.Level * 1000) / 1000;
            this.Level += this.LevelStep;
            var imgType;
            var selector;
            if (this.Level % 1 < this.LevelStep) {
                selector = ".cloudMan .man .lvl" + this.Level.toFixed(0);
                imgType = $(selector).attr("data-imgType");
                $('[data-imgType = ' + imgType).hide();
                $(selector).show();
            }
            if (this.firstClick) {
                this.Level -= this.LevelStep;
                this.firstClick = false;
            }
            element.target.remove();
        };
        Field.prototype.getCloudCount = function () {
            return $(this.fieldSelector + " .cloud").length;
        };
        Field.prototype.setTextTalkCloud = function () {
        };
        return Field;
    }());
    CloudConstruct.Field = Field;
})(CloudConstruct || (CloudConstruct = {}));
window.onload = function () {
    var field = new CloudConstruct.Field(".cloudMan .wrap", 30, 30, 8);
    field.init();
    var isFirstClick = true;
    setInterval(function () {
        if (!isFirstClick)
            field.init();
    }, 3000);
    $(".cloudMan .cloud").on("click", function (element) {
        isFirstClick = false;
        field.actionOnClick(element);
    });
};
//# sourceMappingURL=App.js.map