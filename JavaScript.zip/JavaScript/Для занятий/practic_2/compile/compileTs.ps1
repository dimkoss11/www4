﻿tsc --watch --project tsconfig.json
