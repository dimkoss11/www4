
/// <reference path="types/jquery.d.ts" />
/// <reference path="types/App.d.ts" />


namespace CloudConstruct {



    class Point {
        constructor(x: number, y: number){
            this.x = x;
            this.y = y;
        }
        public x: number;
        public y: number;
    }


    class Cloud {
        constructor(selector: string, point: Point){
            this.selector = selector;
            this.point = point;
        }
        selector: string;
        point: Point;
        static width: number;
        static height: number;

        static isSeparately(allClouds: Cloud[], currentPoint: Point, offset: number = 0, width:number, height: number): boolean{
            if(allClouds.length === 0)
                return true;

            allClouds.forEach(element => {
                if(Cloud.intoRange(element.point.x - offset - Cloud.width / 2, element.point.x + offset + Cloud.width / 2, currentPoint.x))
                    return false
                if(Cloud.intoRange(element.point.y - offset - Cloud.height / 2, element.point.y + offset + Cloud.height / 2, currentPoint.y))
                    return false
            });

            if(currentPoint.x > width - Cloud.width - offset || currentPoint.x < Cloud.width + offset || currentPoint.y > height - Cloud.height - offset || currentPoint.y < Cloud.height + offset )
                return false;

            return true;
        }

        static intoRange(start: number, end: number, x: number){
            return x< start || x > end ? false : true;
        }

        static getAllClouds(cssSelector: string): any {
            let clouds = $(cssSelector);
            if(clouds.length === 0)
                return [];
            return clouds;
        }
    }


    export class Field  {
        constructor( fieldSelector: string, cloudWidth: number, cloudHeight: number, LevelMax: number ){
            this.fieldSelector = fieldSelector;
            this.width = $(fieldSelector).width();
            this.height = $(fieldSelector).height();
            this.LevelMax = LevelMax;
            Cloud.width = cloudWidth;
            Cloud.height = cloudHeight;
            this.LevelStep = LevelMax / this.getCloudCount();
            this.Level = this.LevelStep;
        }
        LevelMax: number; //image layers
        LevelStep: number;
        Level: number;
        firstClick: boolean = true;

        fieldSelector: string;
        width: number;
        height: number;
        cloudCount: number = 0;
        private cloudsJQuery: any[] = Cloud.getAllClouds(".cloudMan .cloud");
        private clouds: Cloud[];

        init() {
            this.clouds = []
            let selector: string;
            this.cloudCount = this.cloudsJQuery.length;
            for(let i = 0; i < this.cloudsJQuery.length; i++){
                selector = "."+this.cloudsJQuery[i].className.replace(' ', '.');
                this.clouds.push(new Cloud(selector, this.getRandomPoint()));
                $(selector).css("left", this.clouds[i].point.x + "px");
                $(selector).css("top", this.clouds[i].point.y + "px");
            }
        }

        private getRandomPoint(): Point{

            let cloudNotIsSeparately: boolean = true
            let point: Point;
            let k: number = 0;
            while (cloudNotIsSeparately) {
                let x = this.random(0, this.width - Cloud.width);
                let y = this.random(0, this.height - Cloud.height);
                point = new Point(x, y);
                cloudNotIsSeparately = !Cloud.isSeparately(this.clouds, point, 10, this.width, this.height);
                if(k++>500)
                    throw("Нету места для нового облака!!!");
            }
            return point;
        }

        private random(min: number, max: number): number {
            var rand = min - 0.5 + Math.random() * (max - min + 1)
            rand = Math.round(rand);
            return rand; 
        }

        actionOnClick(element){
            this.Level = Math.round(this.Level*1000)/1000; // fix js
            this.Level += this.LevelStep;
            let imgType: string;
            let selector: string
    
            if(this.Level % 1 < this.LevelStep){
                selector = ".cloudMan .man .lvl"+ this.Level.toFixed(0);
                imgType = $(selector).attr("data-imgType");
                $('[data-imgType = '+ imgType).hide();
                $(selector).show();
            }
    
            if(this.firstClick){
                this.Level -= this.LevelStep;
                this.firstClick = false;
            }
            element.target.remove();
        }

        getCloudCount(): number{
            return $(this.fieldSelector + " .cloud").length;
        }

        setTextTalkCloud(){
            
        }

    }

}

window.onload=function() {

    let field = new CloudConstruct.Field(".cloudMan .wrap", 30, 30, 8);
    field.init();


    let isFirstClick: boolean = true;
    
    setInterval(function()  {
        if(!isFirstClick)
            field.init();
    }, 3000);

    $(".cloudMan .cloud").on("click", function(element){
        isFirstClick = false;
        field.actionOnClick(element);
    });

      
}