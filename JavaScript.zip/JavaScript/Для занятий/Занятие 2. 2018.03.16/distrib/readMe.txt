Установка копилятора typescript

1 установить VSCode
2 установить nodeJS
3 перейти в VSCode
4 нажать Ctrl + Shift + P
5 ввести "npm install typescript"
6 нажать Enter

Компиляция typescript

1 создать tsconfig.json (\code\compile\tsconfig.json)
2 создать ps1/bat для запуска компилятора (\code\compile\compileTs.ps1)