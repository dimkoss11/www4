
/// <reference path="types/jquery.d.ts" />


/**
 * Объект, содержащий корни квадратного уравнения
 */
class Answer {
    public x1: number;
    public x2: number;
}


/**
 * Вычисление корней квадратного уравнения
 *
 * @param a Первый аргумент a*x^2
 * @param b Второй аргумент b*x
 * @param c Третий аргумент c
 */
function discrim(a: number, b: number, c: number): boolean|number|Answer {
    let discr = Math.pow(b,2) - 4 * a * c;
    if( discr < 0 )
        return false;
    if( discr === 0 )
        return -b/2*a;
    let x1 = ( - b + Math.sqrt(discr) )/ (2 * a);
    let x2 = ( - b - Math.sqrt(discr) )/ (2 * a);
    return {
        x1: x1,
        x2: x2
    };
}
  

/**
 * Получение введенных данных и посчет корней квадратного уравнения
 */
function runCalc(): void{
    debugger
    let x1 = <number>$("#arg1").val();
    let x2 = <number>$("#arg2").val();
    let x3 = <number>$("#arg3").val();
    let obj = discrim( x1, x2, x3 );
    let jsonString: string = JSON.stringify(obj);
    $("#answer").html(jsonString);
}


$( "#calc" ).on( "click", function() {
    runCalc();
});
