
function discrim(a, b, c){
  var discr = Math.pow(b,2) - 4 * a *c;
  if( discr < 0 )
    return false;
  if( discr === 0 )
    return -b/2*a;
  var x1 = ( - b + Math.sqrt(discr) )/ (2 * a);
  var x2 = ( - b - Math.sqrt(discr) )/ (2 * a);
  return {
    x1:x1,
    x2: x2
  };
}


function runCalc(){
  debugger
  x1 = $("#arg1").val();
  x2 = $("#arg2").val();
  x3 = $("#arg3").val();
  var obj = discrim( x1, x2, x3 );
  var jsonString = JSON.stringify(obj);
  $("#answer").html(jsonString);
}


$( "#calc" ).on( "click", function() {
  runCalc();
});
